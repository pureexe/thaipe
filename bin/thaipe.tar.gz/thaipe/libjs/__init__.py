"""
The makeJsLib.py file is going to be called in thaipe.py, thus this file is
required to make this folder importable without putting it in sys.path
"""
