Version/Revision :
	0.1beta2

Future Change :
	See ./thaipe/doc/change.log.

Installation :
	sudo ./0.1b2.run

Run:
	1. First way, only execute. 
		Double click on .htma file.

	2. Second way, only execute. 
		Right click, select "THAIPE Application manager" in open with menu.

	2. third way, Execute with application runtime message. 
		open terminal and type : 
		thaipe /your/program/path/myPlog.htma

Document :
	See ./doc/thaipe directory for more information.

Example :
	See /applications/programming/thaipe/example

License :
	GPL, see ./doc/license.txt  directory.
